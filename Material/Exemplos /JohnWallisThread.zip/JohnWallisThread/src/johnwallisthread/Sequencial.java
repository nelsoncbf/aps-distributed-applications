/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package johnwallisthread;

/**
 *
 * @author 04279207798
 */
public class Sequencial {
    private int n;

    public void setN(int n) {
        this.n = n>1?n:2;
    }
    
    public double aproximacaoPi(){
        double Pi=1.;
        
        for(long i=2; i<n; i+=2){
            Pi *= i * i;
            Pi *= 1./(i-1)/(i+1);
            System.out.println("-> " + i + ")"
                    + 2*Pi);
        }
        
        return 2*Pi;
    }
}
