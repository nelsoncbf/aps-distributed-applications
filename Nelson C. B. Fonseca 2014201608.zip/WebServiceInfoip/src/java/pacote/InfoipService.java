/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pacote;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author nelsonfonseca
 */
@WebService(serviceName = "InfoipService")
public class InfoipService {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "enderecoIp")
    public String sobr(@WebParam(name = "name2") String pgIp) {
        String ips = (pgIp);
        return "Endereço IP: " +pegaIp(ips);
    }
    @WebMethod(operationName = "classe")
    public String clas(@WebParam(name = "pgClass") String pgClass) {
        String ips = (pgClass);
        return "Classe: "+pegaIp(ips);
    }
    @WebMethod(operationName = "mascaraRede")
    public String mask(@WebParam(name = "mascara") String pgMascara) {    
        String mascaraRede = pegaMascara(pgMascara);
        return "Mascarade rede: " + mascara(mascaraRede);
    }
    @WebMethod(operationName = "broadcast")
    public String broa(@WebParam(name = "broadcast") String pgBroadcast) {    
        return "Broadcast: " + broad(pgBroadcast)+".255";
    }
    @WebMethod(operationName = "gateway")
    public String gate(@WebParam(name = "gateway") String pgGateway) {    
        return "Gateway: " + broad(pgGateway)+".1";
    }
    @WebMethod(operationName = "capacidadeEnderecos")
    public String info(@WebParam(name = "info") String pgInfo) {
        String mascaraRede = pegaMascara(pgInfo);
        return "Capacidade: " + infoClasse(mascaraRede);
    }
    @WebMethod(operationName = "infoCompleta")
    public String infoCompleta(@WebParam(name = "infoCompleta") String pgInfoCompleta) {
        String ips = (pgInfoCompleta);
        String mascaraRede = pegaMascara(pgInfoCompleta);
        return "Endereço IP: " +pegaIp(ips)+" - Classe: "+pegaIp(ips)+
        "- Mascarade rede: " + mascara(mascaraRede)+
                "- Broadcast: " + broad(pgInfoCompleta)+".255"+
                "- Gateway: " + broad(pgInfoCompleta)+".1"+
                "- Capacidade: " + infoClasse(mascaraRede);
    }
    
    
        String pegaIp(String ips){
        String[] separando = ips.split("/");
        return separando[0];
    }
    String pegaMascara(String ips){
        String[] separando = ips.split("/");
        int num = Integer.parseInt(separando[1]);
        String ipClass = ("nulo");
        switch (num){
        case 8:
            ipClass = ("255.0.0.0/16.777.216 endereços.");
        break;
        case 16:
            ipClass = ("255.255.0.0/65.536 endereços.");
        break;
        case 20:
            ipClass = ("255.255.240.0/4096 endereços.");
        break;
        case 21:
            ipClass = ("255.255.248.0/2048 endereços.");
        break;
        case 22:
            ipClass = ("255.255.252.0/1024 endereços.");
        break;
        case 23:
            ipClass = ("255.255.254.0/512 endereços.");
        break;
        case 24:
            ipClass = ("255.255.255.0/256 endereços.");
        break;
        case 25:
            ipClass = ("255.255.255.128/128 endereços.");
        break;
        case 26:
            ipClass = ("255.255.255.192/64 endereços.");
        break;
        case 27:
            ipClass = ("255.255.255.224/32 endereços.");
        break;
        case 28:
            ipClass = ("255.255.255.240/16 endereços.");
        break;
        case 29:
            ipClass = ("255.255.255.248/8 endereços.");
        break;
        case 30:
            ipClass = ("255.255.255.252/4 endereços.");
        break;
        case 31:
            ipClass = ("255.255.255.254/2 endereços.");
        break;
        case 32:
            ipClass = ("255.255.255.255/1 endereços.");
        break;
        default:
            ipClass = ("--/O IP digitado é inválido, pois não possui classe");
        break;
        }
        return ipClass;
    }
    String mascara(String mascaraRede){
        String[] a = mascaraRede.split("/");
        String b = a[0];
        return b;
    }
    String infoClasse (String mascaraRede){
        String[] a = mascaraRede.split("/");
        String b = a[1];
        return b;
    }
    String broad (String ip){
        String[] a = ip.split("\\.");
        String b = (a[0]+"."+a[1]+"."+a[2]);
        return b;
    }
    String pegaClasse(String ip){
        String[] a = ip.split("\\.");
        int b = Integer.parseInt(a[0]);
        String vClass;
                 if ((b >=   0) && (b <=127)) vClass = ("A");
            else if ((b >= 128) && (b <=191)) vClass = ("B");
            else if ((b >= 192) && (b <=223)) vClass = ("C");
            else if ((b >= 224) && (b <=239)) vClass = ("D");
            else if ((b >= 240) && (b <=247)) vClass = ("E");
            else vClass = ("IP Inválido");
        return vClass;
    }    
}
